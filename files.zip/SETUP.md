# RENEW — Netlify Deployment Guide

## What's in this folder

```
renew-netlify/
├── netlify.toml              ← Netlify configuration
├── netlify/
│   └── functions/
│       └── chat.js           ← Secure API proxy (keeps your key server-side)
└── public/
    └── index.html            ← Your renew.html goes here (rename it)
```

---

## Step 1 — Put your RENEW file in place

Copy your `renew.html` file into the `public/` folder and rename it `index.html`.

---

## Step 2 — Update the chatbot fetch URL in index.html

Open `public/index.html` and find this line in the chat JavaScript
(near the bottom of the file, inside the `submitMessage` function):

```javascript
fetch('https://api.anthropic.com/v1/messages', {
```

Replace it with:

```javascript
fetch('/api/chat', {
```

Then simplify the request body — remove the `system` field and the headers
(the proxy handles those). The full updated fetch block should look like this:

```javascript
fetch('/api/chat', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ messages: chatHistory })
})
.then(function(r) { return r.json(); })
.then(function(data) {
  document.getElementById('chat-typing').classList.remove('show');
  var reply = data.reply || 'Something went wrong. Please try again.';
  chatHistory.push({ role: 'assistant', content: reply });
  appendMessage('bot', reply);
  chatBusy = false;
  document.getElementById('chat-send-btn').disabled = false;
  if (!chatOpen) { document.getElementById('chat-badge').classList.add('show'); }
})
.catch(function() {
  document.getElementById('chat-typing').classList.remove('show');
  appendMessage('bot', 'I am having trouble connecting right now. Please try again in a moment.');
  chatBusy = false;
  document.getElementById('chat-send-btn').disabled = false;
});
```

Also remove the `SYSTEM_PROMPT` variable from the HTML — it now lives
securely in `netlify/functions/chat.js` and does not need to be in the page.

---

## Step 3 — Create a GitHub repository

1. Go to github.com and sign in (create a free account if needed)
2. Click the **+** button → **New repository**
3. Name it `renew` — make it **Public**
4. Click **Create repository**
5. On the next screen, click **uploading an existing file**
6. Drag the entire `renew-netlify` folder contents into the upload area:
   - `netlify.toml`
   - `netlify/functions/chat.js`
   - `public/index.html`
7. Click **Commit changes**

---

## Step 4 — Deploy on Netlify

1. Go to **netlify.com** and sign in (free account)
2. Click **Add new site → Import an existing project**
3. Choose **GitHub** and select your `renew` repository
4. Netlify will auto-detect the settings from `netlify.toml`:
   - Publish directory: `public`
   - Functions directory: `netlify/functions`
5. Click **Deploy site**

Your site will be live in about 60 seconds at a URL like `renew-abc123.netlify.app`.
You can rename this under **Site settings → Domain management**.

---

## Step 5 — Add your Anthropic API key (the important one)

This is what keeps your key secure — it never touches the HTML file.

1. In Netlify, go to **Site settings → Environment variables**
2. Click **Add a variable**
3. Key: `ANTHROPIC_API_KEY`
4. Value: your Anthropic API key (starts with `sk-ant-...`)
5. Click **Save**
6. Go to **Deploys** and click **Trigger deploy → Deploy site**

The chatbot will now work with your key stored securely on Netlify's servers.

---

## Step 6 — (Optional but recommended) Lock down CORS

Once you have your live domain (e.g. `renew-health.netlify.app` or your custom domain):

1. Go to **Site settings → Environment variables**
2. Add another variable:
   - Key: `ALLOWED_ORIGIN`
   - Value: `https://your-domain.netlify.app` (your exact live URL)
3. Redeploy

This ensures the chatbot API can only be called from your site, not from anyone
else who might find the endpoint.

---

## Getting an Anthropic API key

1. Go to **console.anthropic.com**
2. Sign up for an account
3. Go to **API Keys → Create Key**
4. Copy the key — you will only see it once, so save it somewhere safe
5. You will need to add a credit card and load some credits
   (the chatbot uses Claude Sonnet — approximately $0.003 per conversation)

---

## Updating RENEW in the future

When you want to update the site (new content, corrections, more studies):
1. Make your changes to `index.html`
2. Go to your GitHub repository
3. Click on `public/index.html` → click the pencil (edit) icon → paste updated content → commit
4. Netlify automatically redeploys within 60 seconds

Or drag-and-drop the new file directly into the GitHub repository.

---

## Troubleshooting

**Chatbot says "trouble connecting":**
- Check that `ANTHROPIC_API_KEY` is set in Netlify environment variables
- Check that you redeployed after adding the key
- Check Netlify's Function logs: **Functions tab → chat → View logs**

**Site not updating:**
- Go to **Deploys** and click **Trigger deploy**

**Custom domain:**
- Go to **Domain management → Add custom domain**
- Follow Netlify's DNS instructions for your domain registrar

---

*RENEW · Stanford Colorectal Surgery · Patient Education Resource*
